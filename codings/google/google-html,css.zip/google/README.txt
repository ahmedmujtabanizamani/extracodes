Assignment#1

Internet Programming and web development
Isra University

contents of assignment#1

1) Google page replica without functionalities.
2) media tag added for responsive footer transition.
3) hover effect also added for most of elements.
4) added svg for little magnifer icon in search box.

presented by Ahmed Mujtaba Nizamani
Id# 1701-BSSE 008
