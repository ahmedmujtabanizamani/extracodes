﻿using System;
using System.IO;
using System.Text;
namespace Demo
{
    class MainClass
    {
        public static void Main(string[] arg)
        {

            String FILEPATH = "/home/mujtaba/Downloads/compressed/Floppy.txt";
            String FILENAME = "bsse003.txt";
            String destination = "/home/mujtaba/" + FILENAME;
            String [] n = FILENAME.Split('.');


            FileStream f = new FileStream(FILEPATH, FileMode.Open);
            FileStream d = new FileStream(destination, FileMode.OpenOrCreate);
            //StreamWriter sw = new StreamWriter(d);
            int fileAddress = SearchFile(n[0].ToUpper(), n[n.Length-1].ToUpper(), f);

            if (fileAddress != -1)
            {
                Console.WriteLine(fileAddress + " address");
                
                int blockPos = SearchDataBlock(StartBlock(fileAddress,f));

                int fileSize = GetFileSize(fileAddress, f);
                int blockSize = 1024;
                int blocks = fileSize % blockSize == 0 ? (fileSize / blockSize) : ((fileSize / blockSize) + 1);
                int lastBlock = (fileSize - (blocks - 1) * blockSize);
                int[] block = GetBlocks(fileAddress, f);


                //Printing block addresses 
                for (int i = 0; i < blocks; i++)
                {
                    Console.WriteLine("Block ["+(i+1)+"] = "+block[i]);
                }

                //checking some functions
                Console.WriteLine("Size of file is : " + GetFileSize(fileAddress, f));
                Console.WriteLine("blocks used in file are : " + blocks);
                Console.WriteLine("last block used size is : " + lastBlock);


                //getting file output as string 
                String output = GetFileData(FILENAME,f);


                //writing output into file file
                GetOutputInFile("bsse008.txt", "/home/mujtaba/", f);  //1st argument is filename into partition, second is path where you want output this file, 3rd is actual partition file


                //printing file string output in console
                Console.WriteLine(output);

                //Print2Hex(f, 10); //provide block numbers as input as we know 1024 byte of each block
            }
            else
            {
                Console.WriteLine("not found");
            }
        }

        public static void GetOutputInFile(String fileName, String to, FileStream file)
        {
            String output = GetFileData(fileName, file);
            FileStream d = new FileStream((to + fileName), FileMode.OpenOrCreate);

            //writing into output file
            for (int i = 0; i < output.Length; i++)
            {
                d.WriteByte((byte)output.ToCharArray()[i]);
            }
            d.Flush();
            d.Close();
            d.Dispose();
        }

        public static String GetFileData(String fileName, FileStream file)
        {
            file.Seek(0, SeekOrigin.Begin);
            String[] n = fileName.Split('.');
            int fileAddress = SearchFile(n[0].ToUpper(), n[n.Length - 1].ToUpper(), file);
            int blockSize = 1024;
            int fileSize = GetFileSize(fileAddress, file);
            int blocks = fileSize % blockSize == 0 ? (fileSize / blockSize) : ((fileSize / blockSize) + 1);
            int lastBlock = (GetFileSize(fileAddress, file) - (blocks - 1) * blockSize);

            int[] block=GetBlocks(fileAddress,file);

            String output = "";

            for (int i = 0; i < (blocks); i++)
            {
                if (i == blocks - 1)
                {
                    output += GetBlockData(SearchDataBlock(block[i]), lastBlock, file);
                }
                else
                {
                    output += GetBlockData(SearchDataBlock(block[i]), blockSize, file);
                }
            }
            return output;
        }

        public static int StartBlock(int address, FileStream f )
        {
            f.Seek(address + 26, SeekOrigin.Begin); // seeking for block address 1st block address resides at 26 offset of file start position

            int b1 = f.ReadByte();  //address bytes to position
            int b2 = f.ReadByte();  //same
            String hex = (String.Format("{0:X2}", b2) + String.Format("{0:X2}", b1)); //adding 2 byte block address using hex
            return int.Parse(hex, System.Globalization.NumberStyles.HexNumber); //converting hex to int
        }

        public static int[] GetBlocks(int addr, FileStream f)
        {
            int fileSize = GetFileSize(addr, f);
            int blockSize = 1024;
            int blocks = fileSize % 1024 == 0 ? (fileSize / blockSize) : ((fileSize / blockSize) + 1);
            int[] block = new int[blocks];
            block[0] = StartBlock(addr, f); //1st block

            //calculating block addresses
            for (int i = 1; i < blocks; i++)
            {
                block[i] = NextAddr(block[i - 1], f);
            }
            return block;
        }

        public static int SearchFile(String Name, String Extension, FileStream File)  //extension optional maybe removed soon
        {
            int foundAdr = -1;                            

            File.Seek(2560, SeekOrigin.Begin);  // starting from where file names start, 2560 byte offset where filename starts

            for (int j = 2560; j < 6144; j += 16) //iterate through range,  6144 offset end of file name block 
            {
                String m = "";

                for (int i = 0; i < 16; i++)        //searching row by row
                {
                    byte ub = (byte)File.ReadByte();
                    m = m + (char)ub;
                }
                if (m.Contains(Name) && m.Contains(Extension))      //loose compare technique used but its works :D
                {
                    foundAdr = (j);
                    break;
                }
                m = "";
            }
            return foundAdr;
        }

        public static int SearchDataBlock(int addr)
        {
            return 1024 * addr + 4096;      //that byte offset w
        }

        public static String GetBlockData(int blockAddress, int size, FileStream file)
        {
            file.Seek(blockAddress, SeekOrigin.Begin);
            String data = "";
            for (int i = 0; i < size; i++)
            {
                byte b = (byte)file.ReadByte();
                data = data + (char)b;
            }
            return data;
        }

        public static int NextAddr(int addrBlock, FileStream file)
        {

            //sir arshads algorithm for seperating 3 bytes into 2 12 byte
            int Addr;
            String b1, b2, b3;
            String hex = "";
            Addr = (512 + (addrBlock / 2) * 3);
            file.Seek(Addr, SeekOrigin.Begin);

            b1 = String.Format("{0:X2}", file.ReadByte());
            b2 = String.Format("{0:X2}", file.ReadByte());
            b3 = String.Format("{0:X2}", file.ReadByte());
            hex = b3 + b2 + b1;

            if (addrBlock % 2 != 0)
            {
            return int.Parse(hex.Substring(0,3), System.Globalization.NumberStyles.HexNumber);
            }
            else
            {
                return int.Parse(hex.Substring(3, 3), System.Globalization.NumberStyles.HexNumber);
            }
        }

        public static int GetFileSize(int addr, FileStream file)
        {

            String hex = "";
            file.Seek(addr + 28, SeekOrigin.Begin);

            //reading reverse because of little endian

            hex = String.Format("{0:X2}", (int)file.ReadByte());
            hex = String.Format("{0:X2}", (int)file.ReadByte()) + hex;
            hex = String.Format("{0:X2}", (int)file.ReadByte()) + hex;
            hex = String.Format("{0:X2}", (int)file.ReadByte()) + hex;

            return int.Parse(hex, System.Globalization.NumberStyles.HexNumber);
        }

        public static void Print2Hex(FileStream file, int blocks)   //how many blocks do you want to dump out
        {
            file.Seek(0, SeekOrigin.Begin);
            for (int j = 0; j < (blocks*1024); j+=16)   //hex dump printing block wise
            {
                String m = "";
                StringBuilder a = new StringBuilder();
                StringBuilder aa = new StringBuilder();

                for (int i = 0; i < 16; i++)
                {
                    byte ub = (byte)file.ReadByte();

                    aa.AppendFormat("{0:X2}", ub); //part of hex data string
                    aa.Append(" ");

                    if (i < 11)
                    {
                        m = m + (char)ub;
                    }
                    //extra stuff for decoration
                    if (i == 7)
                    {
                        aa.Append("| ");
                    }

                    //cancelling escape characters because of console asciii 
                    if (ub <= 32)
                    {
                        ub = (byte)'.';
                    }
                    a.Append((char)ub); //part for asciii output string
                }

                Console.Write(String.Format("{0:X8}", (j * 16)) + "    "); // part of addresses
                aa.Append("   " + a);   //adding ascii part into hex part
                Console.WriteLine(aa);
                aa.Clear();
                a.Clear();
                m = "";
            }
        }
    }
}

//##################################################################################
//Programmer : Ahmed Mujtaba
//Student at Isra University

